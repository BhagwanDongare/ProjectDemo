import React from "react";

const Profile = () => {
  return (
    <>
      <h1>Profile Component</h1>
    </>
  );
};

export default Profile;
