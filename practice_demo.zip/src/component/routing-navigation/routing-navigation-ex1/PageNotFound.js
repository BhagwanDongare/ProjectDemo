import React from "react";

const PageNotFoun = () => {
  return (
    <>
      <h1>Page Not Found</h1>
      <p>This page you are looking for is not available</p>
    </>
  );
};

export default PageNotFoun;
