import React from "react";

const Services = () => {
  return (
    <>
      <h1>Service Component</h1>
    </>
  );
};

export default Services;
