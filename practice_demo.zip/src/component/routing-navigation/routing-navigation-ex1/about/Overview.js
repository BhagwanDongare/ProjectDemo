import React from "react";

const Overview = () => {
  return (
    <>
      <h1>Overview Component</h1>
      <p>{"Lorem ipsumlorem".repeat(100)}</p>
    </>
  );
};

export default Overview;
