import React from "react";

const Team = () => {
  return (
    <>
      <h1>Team Component</h1>
      <p>{"Team members".repeat(10)}</p>
    </>
  );
};

export default Team;
