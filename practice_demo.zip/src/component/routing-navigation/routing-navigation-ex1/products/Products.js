import React from "react";

const Products = () => {
  return (
    <>
      <h1>Products Component</h1>
    </>
  );
};

export default Products;
