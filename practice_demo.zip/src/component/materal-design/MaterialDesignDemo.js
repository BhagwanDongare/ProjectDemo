import React from "react";
import Button from "@mui/material/Button";

const MaterialDesignDemo = () => {
  return (
    <>
      <Button variant="contained">Click me</Button>
    </>
  );
};

export default MaterialDesignDemo;
// npm i @emotion/styled
// npm i @emotion/react
