import React from "react";
import Todos from "./Todos";
import UserTask from "./user-task/UserTask";

const HTTPDemo = () => {
  return (
    <>
      <h1>HTTP Demo</h1>
      {/* <Todos /> */}
      <UserTask />
    </>
  );
};

export default HTTPDemo;
