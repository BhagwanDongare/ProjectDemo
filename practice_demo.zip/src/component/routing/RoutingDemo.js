import React from "react";
import RoutingEx1 from "./RoutingEx1";

const RoutingDemo = () => {
  return (
    <>
      <h3>Routing Demo</h3>
      <RoutingEx1 />
    </>
  );
};

export default RoutingDemo;
