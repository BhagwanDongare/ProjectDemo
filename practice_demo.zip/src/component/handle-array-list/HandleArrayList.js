import React from "react";
import ArrayList from "./ArrayList";
import NestedArrayList from "./NestedArrayList";
import ReuseCompList from "./ReuseCompList";

const HandleArrayList = () => {
  return (
    <>
      <h1>Handle Array with list</h1>

      {/* <ArrayList /> */}
      {/* <NestedArrayList /> */}
      <ReuseCompList />
    </>
  );
};

export default HandleArrayList;
