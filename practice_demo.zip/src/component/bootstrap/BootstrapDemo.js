import React from "react";
import { Button } from "react-bootstrap";
const BootstrapDemo = () => {
  return (
    <>
      <h1>Bootstrap Demo</h1>
      <Button>Click Me</Button>
    </>
  );
};

export default BootstrapDemo;
